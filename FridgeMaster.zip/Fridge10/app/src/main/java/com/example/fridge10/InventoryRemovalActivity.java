package com.example.fridge10;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class InventoryRemovalActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_removal);

        Button btnRemove = findViewById(R.id.btnRemove);

        btnRemove.setOnClickListener(v -> {
            // Remove the last item from shared preferences
            removeLastItemFromPreferences();

            // For demonstration purposes, show a Toast message
            Toast.makeText(InventoryRemovalActivity.this, "Last item removed from inventory", Toast.LENGTH_SHORT).show();

            // Optionally, navigate back to the main menu or perform other actions
            finish();
        });
    }

    private void removeLastItemFromPreferences() {
        SharedPreferences preferences = getSharedPreferences("Inventory", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();

        // Get the current inventory (comma-separated)
        String currentInventory = preferences.getString("inventory", "");

        // If the inventory is not empty, remove the last item
        if (!currentInventory.isEmpty()) {
            // Split the inventory into items
            String[] items = currentInventory.split(",");

            // Remove the last item
            StringBuilder newInventory = new StringBuilder();
            for (int i = 0; i < items.length - 1; i++) {
                newInventory.append(items[i]);
                if (i < items.length - 2) {
                    newInventory.append(",");
                }
            }

            // Save the updated inventory back to preferences
            editor.putString("inventory", newInventory.toString());
            editor.apply();
        }
    }
}
