package com.example.fridge10;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText editTextUsername;
    private EditText editTextPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);

        buttonLogin.setOnClickListener(v -> {
            // Handle login button click
            String username = editTextUsername.getText().toString();
            String password = editTextPassword.getText().toString();

            // Add your authentication logic here
            // For simplicity, let's just show a toast message
            if (isValidCredentials(username, password)) {
                // Navigate to the LandingActivity after successful login
                Intent landingIntent = new Intent(LoginActivity.this, LandingActivity.class);
                startActivity(landingIntent);
                finish(); // Close the LoginActivity
            } else {
                // Show an error message if credentials are invalid
                Toast.makeText(LoginActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Example authentication logic (replace with your actual logic)
    private boolean isValidCredentials(String username, String password) {
        // Implement your authentication logic (e.g., check against a database)
        // For simplicity, just check if the fields are not empty
        return !username.isEmpty() && !password.isEmpty();
    }
}
