package com.example.fridge10;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class LandingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.landing_activity);

        Button btnGetStarted = findViewById(R.id.btnGetStarted);

        btnGetStarted.setOnClickListener(v -> {
            // Handle Get Started button click
            // For simplicity, let's assume it directly navigates to MainMenuActivity
            Intent mainMenuIntent = new Intent(LandingActivity.this, MainMenuActivity.class);
            startActivity(mainMenuIntent);
            finish(); // Close the LandingActivity
        });
    }
}
