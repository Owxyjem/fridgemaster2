package com.example.fridge10;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

public class InventoryInputActivity extends Activity {

    private static final String TAG = "InventoryInputActivity";
    private EditText etItemName;
    private ListView lvInventory;
    private Set<String> inventorySet;
    private Calendar expirationCalendar; // Added for expiration date

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_input);

        etItemName = findViewById(R.id.etItemName);
        Button btnSave = findViewById(R.id.btnSave);
        Button btnSetExpiration = findViewById(R.id.btnSetExpiration); // Added for expiration date
        lvInventory = findViewById(R.id.lvInventory);

        // Load existing inventory from SharedPreferences
        loadInventory();

        // Initialize expirationCalendar
        expirationCalendar = Calendar.getInstance();

        btnSave.setOnClickListener(v -> {
            // Get the item name from the EditText
            String itemName = etItemName.getText().toString().trim();

            if (!itemName.isEmpty()) {
                // Add the item and expiration date to the inventory set
                String itemWithExpiration = itemName + " (Expires on " + getFormattedExpirationDate() + ")";
                inventorySet.add(itemWithExpiration);

                // Schedule notification for expiration time
                scheduleExpirationNotification(itemWithExpiration);

                // Save the updated inventory to SharedPreferences
                saveInventory();

                // Update the ListView
                updateInventoryDisplay();

                // For demonstration purposes, show a Toast message
                showToast("Item saved: " + itemName);

                // Clear the EditText for the next input
                etItemName.getText().clear();
            } else {
                showToast("Please enter an item name");
            }
        });

        btnSetExpiration.setOnClickListener(v -> showDatePickerDialog()); // Added for expiration date

        // Display the initial inventory
        updateInventoryDisplay();
    }

    private void loadInventory() {
        SharedPreferences preferences = getSharedPreferences("Inventory", MODE_PRIVATE);
        inventorySet = preferences.getStringSet("inventorySet", new HashSet<>());
    }

    private void saveInventory() {
        SharedPreferences preferences = getSharedPreferences("Inventory", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putStringSet("inventorySet", inventorySet);
        editor.apply();
    }

    private void updateInventoryDisplay() {
        ArrayAdapter<String> inventoryAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>(inventorySet));
        lvInventory.setAdapter(inventoryAdapter);
    }

    private void scheduleExpirationNotification(String itemName) {
        Intent notificationIntent = new Intent(this, NotificationReceiver.class);
        notificationIntent.putExtra("itemName", itemName);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                0,
                notificationIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE // Add FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        try {
            // Use setExact for precise timing on Android versions KitKat and above
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, expirationCalendar.getTimeInMillis(), pendingIntent);
        } catch (SecurityException e) {
            // Handle SecurityException, for example, by using set instead of setExact
            alarmManager.set(AlarmManager.RTC_WAKEUP, expirationCalendar.getTimeInMillis(), pendingIntent);
            Log.e(TAG, "Error scheduling exact alarm: " + e.getMessage());
        }
    }

    private void showDatePickerDialog() {
        // Get the current date to set as the default in the DatePickerDialog
        int year = expirationCalendar.get(Calendar.YEAR);
        int month = expirationCalendar.get(Calendar.MONTH);
        int day = expirationCalendar.get(Calendar.DAY_OF_MONTH);

        // Create a DatePickerDialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, yearSelected, monthOfYear, dayOfMonth) -> {
                    // Set the selected date in expirationCalendar
                    expirationCalendar.set(yearSelected, monthOfYear, dayOfMonth);
                    // Show a toast message with the selected date (for demonstration purposes)
                    showToast("Expiration Date set: " + getFormattedExpirationDate());
                },
                year, month, day);

        // Show the DatePickerDialog
        datePickerDialog.show();
    }

    private String getFormattedExpirationDate() {
        DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.MEDIUM);
        return dateFormat.format(expirationCalendar.getTime());
    }

    private void showToast(String message) {
        Toast.makeText(InventoryInputActivity.this, message, Toast.LENGTH_SHORT).show();
    }
}
