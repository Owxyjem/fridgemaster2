package com.example.fridge10;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import android.widget.Button;

public class MainMenuActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_menu_activity);

        // Add click listeners for each menu option
        Button btnInputInventory = findViewById(R.id.InputInventory);
        Button btnRemoveInventory = findViewById(R.id.RemoveInventory);
        Button btnNotifications = findViewById(R.id.Notifications);
        Button btnRecipeSuggestions = findViewById(R.id.RecipeSuggestions);

        btnInputInventory.setOnClickListener(v -> {
            // Start InventoryInputActivity
            Intent inputIntent = new Intent(MainMenuActivity.this, InventoryInputActivity.class);
            startActivity(inputIntent);
        });

        btnRemoveInventory.setOnClickListener(v -> {
            // Start InventoryRemovalActivity
            Intent removeIntent = new Intent(MainMenuActivity.this, InventoryRemovalActivity.class);
            startActivity(removeIntent);
        });

        btnNotifications.setOnClickListener(v -> {

        });

        btnRecipeSuggestions.setOnClickListener(v -> {

        });

    }
}
